import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Ecom App UI',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        actions: [
          Icon(Icons.notifications)
        ],
      ), //AppBar
      body: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: EdgeInsets.all(10),
          child: TextField(
            decoration: InputDecoration(border: OutlineInputBorder(), labelText: 'Username', hintText: 'Enter Your Name', suffixIcon: Icon(Icons.search)),
          ), //TextField
        ), //Container1
        Container(
          padding: EdgeInsets.fromLTRB(28, 10, 0, 0),
          child: Text('History',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
              )),
        ), //Container2
        Container(
            padding: EdgeInsets.all(12),
            child: Column(children: [
              ABC("im1.jpg", "Iphone 12"),
              ABC("im2.jpg", "Note 20 Ultra"),
              ABC("im3.jpg", "Macbook Air"),
              ABC("im4.jpg", "Macbook Pro"),
              ABC("im5.jpg", "Gaming Pc"),
              ABC("im6.jpg", "Backlit Keyword"),
              ABC("im7.jpeg", "Mercedes"),
              ABC("im8.jpg", " Mutton"),
              ABC("im9.jpg", "Rockster"),
              ABC("im10.jpg", "Royal Field"),
            ]) //Column

            ), //Container3
      ]) //Column
          ), //SingleChildScrollView
    ); //Scaffold
  }
}

Widget ABC(String image, String name) {
  return (ListTile(
    leading: CircleAvatar(
      radius: 20,
      backgroundImage: AssetImage('assets/images/$image'),
    ), //CircularAvatar
    title: Text(
      '$name',
      style: TextStyle(
        fontWeight: FontWeight.bold,
      ),
    ), //title
    subtitle: Row(
      children: [
        Image.asset(
          'assets/images/star.png',
          width: 20,
          height: 20,
        ),
        Text(
          ' 5.0 (23 Reviews)',
          style: TextStyle(
            fontSize: 13,
          ),
        ),
      ],
    ), //SubTitle
    trailing: Text('\$10'), //Trailing
  ) //ListTile

      );
}
