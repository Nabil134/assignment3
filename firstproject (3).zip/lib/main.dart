import 'package:flutter/material.dart';
import 'home.dart';
import 'history.dart';

import 'user.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, //Removing Debug Banner
      home: Scaffold(body: Home()),
    );
  }
}
